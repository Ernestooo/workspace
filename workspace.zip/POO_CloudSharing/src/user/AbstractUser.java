package user;

public abstract class AbstractUser implements User {
	
	protected String email, type;
	protected int occupiedSpace, availableSpace, counter, currentFile;
	protected boolean isPremium;
	protected File files[];
	
	private static final int DEFAULT = 100;
	protected static final int BASIC_USER_SIZE = 2 * 1024;
	protected static final int PREMIUM_USER_SIZE = 5 * 1024;
	public static final String BASIC = "basic";
	public static final String PREMIUM = "premium";
	
	protected AbstractUser(String email, String type){
		this.email = email;
		this.type = type;
		files = new File [DEFAULT];
		counter = 0;
		currentFile = -1;
		occupiedSpace = 0;
	}
	
	public String getEmail(){
		return email;
	}
	
	public String getType(){
		return type;
	}
	
	public int numberOfFiles(){
		return counter;
	}
	
	public int getAvailableSpace(){
		return availableSpace;
	}
	
	public int getOccupiedSpace(){
		return occupiedSpace;
	}
	
	
	public void addFiles(String fileName, int size, String owner){
		if (counter == files.length)
			resize();
		files [counter++] = new FileClass (fileName, size, owner);
		occupiedSpace =+ size;
		availableSpace =- size;
	}
	
	protected void resize() {
		File [] aux = new File [files.length * 2];
		for (int i = 0; i < files.length; i++)
			aux [i] = files [i];

		files = aux;
	}
	
	private int searchIndex(String email) {
		boolean found = false;
		int result = -1;
		int i = 0;
		while (i<counter && !found)
			if (files[i].getOwner().equals(email))
				found = true;
			else
				i++;
		if (found)
			result = i;
		return result;
	}
	
	public boolean hasUser(String email){
		return (searchIndex(email)>=0);
	}
	
	public void initIterator() {
		currentFile = 0;
	}
	
	public boolean hasNext() {
		return ((currentFile >= 0) && (currentFile < counter));
	}

	public File next() {
		return files [currentFile++];
	}

	public abstract int getTotalSpace();
	
	public abstract void shareFile(String fileName, int size, String owner);
	
	public abstract boolean spaceAvailable(int size);
	
}
