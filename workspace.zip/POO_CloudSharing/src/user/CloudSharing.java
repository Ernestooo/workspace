package user;

public interface CloudSharing {
	void addUser(String email, String type);
	
	void uploadFile(String email, String fileName, int size);
	
	int getSpaceAvaiable(String email);
	
	int numberOfAccounts();
	
	void initIterator();
	
	boolean hasNext();
	
	User next();

	boolean userExists(String email);
	
	User getUser(String email);
}
