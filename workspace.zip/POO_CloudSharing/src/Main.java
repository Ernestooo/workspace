import java.util.Scanner;
import user.CloudSharing;
import user.User;
import user.BasicUser;
import user.PremiumUser; 
import user.CloudSharingClass;
import user.AbstractUser;
import user.File;
import user.FileClass;

public class Main {
	public static final String ADD_USER			= "ADD";
	public static final String UPLOAD_FILE		= "REGISTA";
	public static final String SHARE_FILE 		= "CONSULTAAMIZADE";
	public static final String LESS_SPACE_ACC	= "MINSPACE";
	public static final String LIST_ALL_FILES	= "LISTFILES";
	public static final String LIST_ALL_ACCS	= "LISTALL";
	public static final String QUIT				= "EXIT";

	public static final String USER_ADDED					= "Account was added.";
	public static final String USER_EXISTS					= "Account already exists.";
	public static final String USER_NOT_EXIST				= "Account does not exist.";
	public static final String FILE_UPLOADED				= "File uploaded into account.";
	public static final String FILE_EXISTS					= "File already exists in the account.";
	public static final String FILE_OVERCAPACITY			= "File size exceeds account capacity";
	public static final String FILE_SHARED					= "File was shared.";
	public static final String FILE_NOT_EXIST				= "File does not exist.";
	public static final String SHARE_NOT_ALLOWED			= "Account does not allow file sharing.";
	public static final String FILE_ALREADY_SHARED			= "File already shared.";
	public static final String ACC_LEAST_SPACE				= "Account with least free space: ";
	public static final String NO_ACCS						= "No accounts.";
	public static final String FILES_HEADER					= "Account files:";
	public static final String ERROR    					= "Error";
	public static final String EXIT							= "Exiting...";

	private static String getCommand (Scanner in) {
		return in.nextLine().toUpperCase();
	}

	private static void interpreter() {
		Scanner in = new Scanner(System.in);
		String comm = getCommand(in);
		CloudSharing cShare = new CloudSharingClass();

		while (!comm.equals(QUIT)){
			switch (comm) {
			case ADD_USER:
				add(cShare, in);
				break;
			case UPLOAD_FILE:
				upload(cShare ,in);
				break;
			case SHARE_FILE:
				share(cShare, in);
				break;
			case LESS_SPACE_ACC:
				lessSpace(cShare, in);
				break;
			case LIST_ALL_FILES:
				listAllFiles(cShare, in);
				break;
			case LIST_ALL_ACCS:
				listAllAccs(cShare, in);
				break;
			default:
				System.out.println(ERROR);
				break;
			}
			comm = getCommand(in);
//			System.out.println();
		}
		System.out.println(EXIT);
//		System.out.println();
		in.close();
	}
	
	private static void upload(CloudSharing cShare, Scanner in) {
		// TODO Auto-generated method stub
		String email =
	}

	private static void add(CloudSharing cShare, Scanner in) {
		// TODO Auto-generated method stub
		String email = in.nextLine();
		String type = in.nextLine();
		
		if (cShare.userExists(email) == false){
			cShare.addUser(email, type);
			System.out.println(USER_ADDED);
		}
		else
			System.out.println(USER_EXISTS);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		interpreter();
	}
		
}



