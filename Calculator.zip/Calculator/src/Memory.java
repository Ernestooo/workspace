
public class Memory {
	private String memory;
	private double value;
	
	public Memory(String a) {
		memory = a;
	}
	public String getName() {
		return memory;
	}

	public double getValue() {
		return value;
	}

	public void setValue(double b) {
		value = b;
	}
	
}