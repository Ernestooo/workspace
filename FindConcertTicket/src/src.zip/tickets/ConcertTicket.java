package tickets;

public interface ConcertTicket extends Ticket{
	
	int getNumberOfPeople();

}
