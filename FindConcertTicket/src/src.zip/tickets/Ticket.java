package tickets;

import shows.*;

public interface Ticket {
	
	int getPrice();
	
	Show getShow();
}
