package shows;

import java.util.Iterator;

import artists.Artist;
import tickets.ConcertTicket;

public interface ShowConcert extends Show {
	
	int getPrice();
	
	Artist getArtist();
	
	void buyTicket(int numberOfPeople);
	
	Iterator<ConcertTicket> ticketsIterator();
	
	int getAmountOfTickets();
	
	int compareNumberOfTicketsTo(Show show);

}
