package shows;

import java.time.LocalDate;

public interface Show extends Comparable<Show>{

	String getShowName();
	
	String getDescription();
	
	int ticketsAvailable();
	
	LocalDate getStartDate();
	
	int getAmountOfTickets();
	
	int soldTickets(int tickets);
	
	int getTicketsSold();
}
