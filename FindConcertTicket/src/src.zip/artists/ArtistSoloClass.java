package artists;

public class ArtistSoloClass extends ArtistClass implements ArtistSolo {

	public ArtistSoloClass(String name, int numberOfAlbums, int numberOfMembers) {
		super(name, numberOfAlbums, numberOfMembers);
		// TODO Auto-generated constructor stub
	}

}
