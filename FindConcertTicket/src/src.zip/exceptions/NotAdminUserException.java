package exceptions;

public class NotAdminUserException extends Exception {
	
	public NotAdminUserException(){
		super();
	}

}
