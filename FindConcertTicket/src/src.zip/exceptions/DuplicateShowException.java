package exceptions;

public class DuplicateShowException extends Exception {
	
	public DuplicateShowException(){
		super();
	}

}
