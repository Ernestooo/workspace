package exceptions;

public class LoggedUserException extends Exception {
	
	public LoggedUserException(){
		super();
	}

}
