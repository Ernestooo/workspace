package exceptions;

public class NotLoggedUserException extends Exception {
	
	public NotLoggedUserException(){
		super();
	}

}
