package exceptions;

public class UserNotExistException extends Exception {
	
	public UserNotExistException(){
		super();
	}

}
