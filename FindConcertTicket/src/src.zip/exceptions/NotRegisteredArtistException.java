package exceptions;

public class NotRegisteredArtistException extends Exception {
	
	public NotRegisteredArtistException(){
		super();
	}

}
