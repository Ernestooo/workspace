package exceptions;

public class AlreadyLoggedException extends Exception {
	
	public AlreadyLoggedException(){
		super();
	}

}
