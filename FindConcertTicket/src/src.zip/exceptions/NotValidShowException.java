package exceptions;

public class NotValidShowException extends Exception {
	
	public NotValidShowException(){
		super();
	}

}
