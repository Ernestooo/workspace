package exceptions;

public class NotValidPasswordException extends Exception {
	
	public NotValidPasswordException(){
		super();
	}

}
