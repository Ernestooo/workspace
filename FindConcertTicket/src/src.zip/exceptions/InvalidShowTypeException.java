package exceptions;

public class InvalidShowTypeException extends Exception {
	
	public InvalidShowTypeException(){
		super();
	}

}
