package exceptions;

public class NotEnoughTicketsException extends Exception {
	
	public NotEnoughTicketsException(){
		super();
	}

}
