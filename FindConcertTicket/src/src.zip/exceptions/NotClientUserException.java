package exceptions;

public class NotClientUserException extends Exception {
	
	public NotClientUserException(){
		super();
	}

}
