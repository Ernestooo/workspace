package exceptions;

public class DuplicateArtistException extends Exception {
	
	public DuplicateArtistException(){
		super();
	}

}
