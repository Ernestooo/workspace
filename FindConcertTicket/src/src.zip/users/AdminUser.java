package users;

public interface AdminUser {

}
