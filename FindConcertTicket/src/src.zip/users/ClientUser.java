package users;

import java.util.Iterator;

import tickets.Ticket;

public interface ClientUser {
	
	String getType();
	
	void buyTicket(Ticket t);
	
	Iterator<Ticket> myTickets();
	
}
