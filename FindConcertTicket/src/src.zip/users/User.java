package users;

public interface User {
	
	static final String ADMIN = "admin";
	static final String CLIENT = "client";
	
	String getEmail();
	
	String getPassword();
	
	boolean checkPassword(String password);
	
	boolean isLoggedIn();
	
	void login();
	
	void logout();
	
	abstract String getType();
}
