package controller;

/**
 * @author Ivan Domingues 49948 || Tiago Matias 50751
 */

import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import artists.Artist;
import exceptions.*;
import shows.Show;
import tickets.Ticket;
import users.User;

public interface Controller {
	
	/**
	 * Adds a <code> User </code> of the given <code> type </code> associated with the give <code> email </code>
	 * @param type
	 * @param email
	 * @throws DuplicateUserException 
	 * @throws LoggedUserException 
	 */
	void addUser(String type, String email) throws DuplicateUserException, LoggedUserException;
	
	/**
	 * Adds a ArtistSolo to the Map of registeresd Artists
	 * Only an AdminUser can execute this method
	 * Only new Artists can be added
	 * @param artistName
	 * @param numberOfAlbums
	 * @param discography
	 * @param numberOfMembers
	 * @throws NotAdminUserException
	 * @throws DuplicateArtistException
	 */
	void addArtistSolo(String artistName, int numberOfAlbums, List<String> discography, int numberOfMembers) throws NotAdminUserException, DuplicateArtistException;
	
	/**
	 * Adds a ArtistBand to the Map of registered Artists
	 * Only an AdminUser can execute this method
	 * Only new Artists can be added to the Map
	 * @param bandName
	 * @param numberOfAlbums
	 * @param discography
	 * @param numberOfMembers
	 * @param members
	 * @throws NotAdminUserException
	 * @throws DuplicateArtistException
	 */
	void addArtistBand(String bandName, int numberOfAlbums, List<String> discography, int numberOfMembers, List<String> members) throws NotAdminUserException, DuplicateArtistException;
	
	/**
	 * Checks if exists an Artist with the given <code> name </code> in the Map <code> artists </code>
	 * @param name
	 * @return true if the Artist exists in the Map, false otherwise
	 */
	boolean hasArtist(String name);
	
	/**
	 * Searches for an Artist with the <code> name </code> on the Map <code> artists </code>
	 * @param name
	 * @return the Artist if exists in the Map, returns null otherwise
	 */
	Artist getArtist(String name);
	
	/**
	 * Adds a ShowConcert to the List <code> shows </code>
	 * Only an AdminUser can execute this command
	 * Only adds new ShowConcert to the List
	 * Only adds Show Concert with Artists that exist in <code> artists </code>
	 * @param showName
	 * @param description
	 * @param numberOfTickets
	 * @param artistName
	 * @param date
	 * @param ticketPrice
	 * @throws NotAdminUserException
	 * @throws DuplicateShowException
	 * @throws NotRegisteredArtistException
	 */
	void addShowConcert(String showName, String description, int numberOfTickets, String artistName, LocalDate date, int ticketPrice) throws NotAdminUserException, DuplicateShowException, NotRegisteredArtistException;
	
	/**
	 * Adds a new ShowFestival to the List <code> shows </code>
	 * Only an AdminUser can execute this method
	 * Only adds new ShowFestival to the List
	 * Only adds ShowFestival that all Artists exist in the Map <code> artists </code>
	 * @param showName
	 * @param description
	 * @param numberOfTickets
	 * @param duration
	 * @param startDate
	 * @param card
	 * @param pricePerDays
	 * @throws NotAdminUserException
	 * @throws DuplicateShowException
	 * @throws NotRegisteredArtistException
	 */
	void addShowFestival(String showName, String description, int numberOfTickets, int duration, LocalDate startDate, Map<LocalDate, List<Artist>> card, Map<Integer,Integer> pricePerDays) throws NotAdminUserException, DuplicateShowException, NotRegisteredArtistException;
	
	/**
	 * Checks if all the Artists of the Festival exist in the Map <code> artists </code>
	 * @param date
	 * @param card
	 * @param duration
	 * @return true if all Artists exist in the Map, false otherwise 
	 */
	boolean hasArtistFestival(LocalDate date, Map<LocalDate, List<Artist>> card, int duration);
	
	/**
	 * 
	 * @param email
	 * @return the <code> User </code> with the given <code> email </code>
	 */
	User getUser(String email);
	
	/**
	 * Checks if exists a <code> User </code> with the given <code> email </code>
	 * @param email
	 * @return true if exists one, returns false otherwise
	 */
	boolean hasUser(String email);
	
	/**
	 * Checks if ther is a User logged in
	 * @return true if <code> loggedUser </code> != null, false otherwise
	 */
	boolean isAUserLoggedIn();
	
	/**
	 * Checks if the User logged in is the one with the given <code> email </code>
	 * @param email
	 * @return if the <code> loggedUser </code> email is the equal to <code> email </code>
	 */
	boolean userLoggedIn(String email);
	
	/**
	 * Checks if the <code> password </code> is the same of the user with the given <code> email </code>
	 * @param email
	 * @param password
	 * @return true if its the same, false otherwise
	 */
	boolean checkPassword(String email, String password);
	
	/**
	 * Loggs in a the User with the given <code> email </code> and <code> password </code>
	 * Only registered Users can be loggedIn
	 * Only one User can logged in at a time
	 * If the User is already logged in cannot be logged in again
	 * Only if the <code> password </code> is correct can the User login
	 * @param email
	 * @param password
	 * @throws UserNotExistException
	 * @throws AlreadyLoggedException
	 * @throws LoggedUserException
	 * @throws NotValidPasswordException
	 */
	void login(String email, String password) throws UserNotExistException, AlreadyLoggedException, LoggedUserException,NotValidPasswordException;
	
	/**
	 * Logs out the <code> loggedUser </code>
	 * Only if <code> loggedUser </code> != null it can be logged out
	 * @return the <code> email </code> of the <code> loggedUser </code>
	 * @throws NotLoggedUserException
	 */
	String logout() throws NotLoggedUserException;
	
	/**
	 * Checks if the <code> loggedUser </code> is an AdminUser
	 * @return true if it is, false otherwise
	 */
	boolean isUserAdmin();
	
	/**
	 * Checks if the <code> loggedUser </code> is a ClientUser
	 * @return true if it is, false otherwise
	 */
	boolean isUserClient();
	
	/**
	 * Checks if has a Show in the given <code> date </code> with the same name as the given
	 * @param date
	 * @param name
	 * @return true if exists one, false otherwise
	 */
	boolean hasShow(LocalDate date, String name);
	
	/**
	 * Searches for the Show with <code> startDate </code> equal to <code> date </code> and the same name
	 * If !hasShow(date, name) throws NotValidShowException 
	 * @param date
	 * @param name
	 * @return the Show on <code> date </code> and with <code> name </code>
	 * @throws NotValidShowException
	 */
	Show getShow(LocalDate date, String name) throws NotValidShowException;
	
	/**
	 * Lists the shows by the order of addition
	 * @return an Iterator<Show>
	 */
	Iterator<Show> getShowsIterator();
	
	/**
	 * Orders the Show of the given <code> type </code> by Date from the closest Date to the most far
	 * If <code> type </code> is not Concert or FEstival throws InvalidShowTypeException
	 * @param type
	 * @return an Iterator of the List
	 * @throws InvalidShowTypeException
	 */
	Iterator<Show> showsByTypeIterator(String type) throws InvalidShowTypeException;
	
	/**
	 * Orders a list of Shows of the the artist with given <code> artistName </code>
	 * First its added the ShowConcert then the ShowFestival
	 * @param artistName
	 * @return the Iterator of List
	 */
	Iterator<Show> showsByArtistIterator(String artistName);
	
	/**
	 * Orders the shows in a List by the number of sold Tickets from the most sold to the less
	 * @return Iterator of the list
	 */
	Iterator<Show> showsByClients();
	
	/**
	 * Orders a list of ShowFestival of the artist with given <code> artistName </code> 
	 * @param artistName
	 * @return the Iterator of the List
	 */
	Iterator<Show> festivalsByArtistIterator(String artistName);
	
	/**
	 * 
	 * @param showName
	 * @param date
	 * @param numberOfPeople
	 * @throws NotClientUserException
	 * @throws NotValidShowException
	 * @throws NotEnoughTicketsException
	 */
	void buyConcertTicket(String showName, LocalDate date, int numberOfPeople) throws NotClientUserException, NotValidShowException, NotEnoughTicketsException;
	
	Iterator<Ticket> userTickets();
	
	void buyFestivalTicket(String showName, LocalDate startDate, List<LocalDate> dates, int numberOfDays) throws NotClientUserException, NotValidShowException, NotEnoughTicketsException;

}
