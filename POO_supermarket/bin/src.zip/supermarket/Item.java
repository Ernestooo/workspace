package supermarket;

/**
 * 
 * @author Ivan Domingues 49948 || Beatriz Andre 50252
 *
 */

public interface Item {

	String getName();
	
	int getVolume();
	
	int getPrice();
}
