package characters;

public enum Movements {
	
	U, D, R, L;

}
