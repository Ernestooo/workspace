package entities;

public abstract class EntitiesClass implements Entities {
	
	public EntitiesClass(){
		
	}

	public abstract char symbol();

}
