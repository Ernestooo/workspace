package map;

import characters.*;
import entities.Entities;
import items.*;

public class MapClass implements Map {
	
	private Location[][] map;
	private int row;
	private int col;
	private int counter;
	private Stormtrooper[] stormtroopers;
	
	private static final int DEFAULT_SIZE = 100;
	
	public MapClass(char [][] map, int row, int col){
		this.row = row;
		this.col = col;
		this.map = new Location[row+1][col+1];
		stormtroopers = new Stormtrooper[DEFAULT_SIZE];
		counter = 0;
		createMap(map);
	}
	
	public int getRows() {
		return row;
	}

	public int getColumns() {
		return col;
	}

	public Location getLocation(int row, int col) {
		return map[row][col];
	}
	
	public char getSymbol(int row, int col){
		return map[row][col].symbol();
	}
	
	/** ITERADOR (TODO)
	 * 
	public Iterator<Location> mapIterator() {
		return new MapIteratorClass(map,row,col);
	}
	*
	*/
	
	private void createMap(char [][] map){
		for(int r = 1; r <= row; r++){
			for(int c = 1; c <= col; c++){
				switch(map[r][c]){
				case EmptySpace.EMPTY:
					this.map[r][c] = new EmptySpaceClass();
					break;
					
				case Gun.GUN:
					this.map[r][c] = new EmptySpaceClass();
					Gun g = new GunClass();
					((EmptySpace)this.map[r][c]).addGun();
					break;
					
				case Potion.POTION:
					this.map[r][c] = new EmptySpaceClass();
					Potion p = new PotionClass();
					((EmptySpace)this.map[r][c]).addPotion();
					break;
					
				case Wall.WALL:
					this.map[r][c] = new WallClass();
					break;
					
				case StormtrooperBlack.STORMB:
					this.map[r][c] = new EmptySpaceClass();
					StormtrooperBlack stb = new StormtrooperBlackClass();
					stb.arrive(r, c);
					((EmptySpace)this.map[r][c]).addStormB(stb);
					stormtroopers[counter++] = ((EmptySpace)this.map[r][c]).returnStormtrooper();
					break;
					
				case StormtrooperWhite.STORMW:
					this.map[r][c] = new EmptySpaceClass();
					StormtrooperWhite stw = new StormtrooperWhiteClass();
					stw.arrive(r, c);
					((EmptySpace)this.map[r][c]).addStormW(stw);
					stormtroopers[counter++] = ((EmptySpace)this.map[r][c]).returnStormtrooper();
					break;
				
				case StormtrooperOrange.STORMO:
					this.map[r][c] = new EmptySpaceClass();
					StormtrooperOrange sto = new StormtrooperOrangeClass();
					sto.arrive(r, c);
					((EmptySpace)this.map[r][c]).addStormO(sto);
					stormtroopers[counter++] = ((EmptySpace)this.map[r][c]).returnStormtrooper();
					break;
				}
			}
		}
	}
	
	private void resize(){
		Stormtrooper[] tmp = new Stormtrooper[2*DEFAULT_SIZE];
		for(int i = 0; i < counter; i++){
			tmp[i] = stormtroopers[i];
		}
		stormtroopers = tmp;
	}
	
	public Stormtrooper[] returnArray(){
		return stormtroopers;
	}
	
	public int getCounter(){
		return counter;
	}
	
	public void addRebel(Rebel rebel, int r, int c){
		if(isEmpty(r,c)){
			((EmptySpace)map[r][c]).addRebel(rebel);
		}
	}
	
	public void removeRebel(int r, int c){
		((EmptySpace)map[r][c]).removeRebel();
	}
	
	public boolean isEmpty(int r, int c){
		return map[r][c] instanceof EmptySpace;
	}

	public boolean canMove(int r, int c){
		return (!(map[r][c] instanceof Wall) && !((EmptySpace)map[r][c]).hasRebel());
	}
	
	public boolean canMoveStorm(int r, int c){
		return (!(map[r][c] instanceof Wall) && !((EmptySpace)map[r][c]).hasStorm());
	}
	public void removeStormtrooper(int r, int c){
		((EmptySpace)map[r][c]).removeStormtrooper();
	}
	
	public boolean isValidPosition(int r, int c){
		return map[r][c].symbol() == EmptySpace.EMPTY;
	}
	
	public boolean isInsideMap(int r, int c){
		return (1 <= r &&  r <= getRows()  && 1 <= c && c <= getColumns());
	}

	
	
}
