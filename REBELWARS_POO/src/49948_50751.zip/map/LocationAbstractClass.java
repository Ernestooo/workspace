package map;

public abstract class LocationAbstractClass implements Location {
	
	public LocationAbstractClass(){
		
	}

	@Override
	public abstract char symbol();


}
