package map;

import characters.*;
import entities.Entities;
import items.*;

public class EmptySpaceClass extends LocationAbstractClass implements EmptySpace {
	
	private Gun gun;
	private Potion potion;
	private Rebel rebel, superCharged;
	private StormtrooperBlack stormtrooperB;
	private StormtrooperWhite stormtrooperW;
	private StormtrooperOrange stormtrooperO;
	
	public EmptySpaceClass(){
		super();
		gun = null;
		potion = null;
		stormtrooperB = null; 
		stormtrooperW = null;
		stormtrooperO = null;
		rebel = null;
		superCharged = null;
		//emptySpace = ;
	}

	@Override
	public char symbol() {
		char c = interact();
		return c;
	}
	
	
	@SuppressWarnings("static-access")
	public char interact(){
		char c = ' ';
		if(rebel != null && stormtrooperB != null){
			c = stormtrooperB.symbol();
			stormtrooperB.captureRebel(rebel);
			removeRebel();
		}
		else if(rebel != null && stormtrooperW != null){
			c = stormtrooperW.symbol();
			stormtrooperW.captureRebel(rebel);
			removeRebel();
		}
		else if(rebel != null && stormtrooperO != null){
			c = stormtrooperO.symbol();
			stormtrooperO.captureRebel(rebel);
			removeRebel();
		}
		else if(rebel != null && gun != null){
			c = rebel.symbol();
			removeGun();
		}
		else if(rebel != null && potion != null){
			c = superCharged.SUPERCHARGED;
			rebel.drinkPotion();
			removePotion();
		}
		else if(superCharged != null && stormtrooperB != null){
			c = superCharged.symbol();
			removeStormtrooper();
		}
		else if(superCharged != null && stormtrooperW != null){
			c = superCharged.symbol();
			removeStormtrooper();
		}
		else if(superCharged != null && stormtrooperO != null){
			c = superCharged.symbol();
			removeStormtrooper();
		}
		else if(stormtrooperB != null && gun != null){
			c = stormtrooperB.symbol();
		}
		else if(stormtrooperO != null && gun != null){
			c = stormtrooperO.symbol();
		}
		else if(stormtrooperW != null && gun != null){
			c = stormtrooperW.symbol();
		}
		else if(stormtrooperB != null){
			c = stormtrooperB.symbol();
		}
		else if(stormtrooperW != null){
			c = stormtrooperW.symbol();
		}
		else if(stormtrooperO != null){
			c= stormtrooperO.symbol();
		}
		else if(gun != null){ 
			c = gun.GUN;
		}
		else if(potion != null){
			c = potion.POTION;
		}
		else if(rebel != null){
			c = rebel.symbol();
		}
		else if(superCharged != null){
			c = superCharged.symbol();
		}
		else{
			gun = null;
			potion = null;
			stormtrooperB = null; 
			stormtrooperW = null;
			stormtrooperO = null;
			rebel = null;
			superCharged = null;
		}
		return c;
	}
	
	

	@Override
	public boolean hasRebel(){
		return rebel != null || superCharged != null;
	}
	
	public boolean hasGun(){
		return gun != null;
	}
	
	public boolean hasStorm(){
		return ( stormtrooperB != null || stormtrooperW != null || stormtrooperO != null);
	}
	
	public void addStormB(StormtrooperBlack st){
		stormtrooperB = st;
	}
	
	public void addStormO(StormtrooperOrange st){
		stormtrooperO = st;
	}
	
	public void addStormW(StormtrooperWhite st){
		stormtrooperW = st;
	}
	
	public Stormtrooper returnStormtrooper(){
		if(stormtrooperB != null)
			return stormtrooperB;
		else if(stormtrooperW != null)
			return stormtrooperW;
		else if(stormtrooperO != null)
			return stormtrooperO;
		return null;
	}
	
	public void removeStorm(){
		stormtrooperB = null;
		stormtrooperW = null;
		stormtrooperO = null;
	}
	
	public void addRebel(Rebel r){
		if(r.isSuperCharged())
			superCharged = r;
		else
			rebel = r;
	}
	
	public void removeRebel(){
		rebel = null;
		superCharged = null;
	}
	
	public void removeStormtrooper(){
		stormtrooperB = null;
		stormtrooperW = null;
		stormtrooperO = null;
	}
	
	public void addGun(){
		gun = new GunClass();
	}
	
	public void removeGun(){
		gun = null;
	}
	
	public void addPotion(){
		potion = new PotionClass(); 
	}
	
	public void removePotion(){
		potion = null;
	}
}
