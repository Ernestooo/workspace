package map;

public class WallClass extends LocationAbstractClass implements Wall {

	public WallClass() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public char symbol() {
		// TODO Auto-generated method stub
		return Wall.WALL;
	}


}
