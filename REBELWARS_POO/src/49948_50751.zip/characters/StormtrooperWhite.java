package characters;

/**
 * 
 * @author Ivan Domingues 49948 || Tiago Matias 50751
 *
 */

public interface StormtrooperWhite extends Stormtrooper{
	
	static final char STORMW = 'W';

}
