package items;

import entities.Entities;

/**
 * 
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

public interface Gun extends Entities{
	
	static final char GUN = '.';

}
