/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package iterator;

public class PathIteratorClass implements PathIterator {

	private int [][] path;
	private int currentRow;
	private int currentCol;
	private int countRows;
	private int countCols;
	
	public PathIteratorClass(int[][] path, int countRows, int countCols){
		this.path = path;
		currentRow = 0;
		currentCol = 0;
		this.countRows = countRows;
		this.countCols = countCols;
	}

	@Override
	public void init() {
		currentRow = 0;
		currentCol = 0;
	}

	@Override
	public boolean hasNext() {
		return (currentRow < countRows || currentCol < countCols);
	}
	
	public int next(){
		int x = 0;
		if(currentCol == countCols){
			x =  path[currentRow++][currentCol];
			currentCol = 0;
		}
		else{
			x = path[currentRow][currentCol++];
		}		
		return x;
	}

}
