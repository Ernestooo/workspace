/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package iterator;

public interface PathIterator {
	
	void init();
	
	boolean hasNext();
	
	int next();
	
}
