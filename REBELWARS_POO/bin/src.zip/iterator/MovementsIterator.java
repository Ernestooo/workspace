/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package iterator;

import characters.Movements;

public interface MovementsIterator {
	
	void init();
	
	int getCurrent();
	
	boolean hasNext();
	
	Movements next();

}
