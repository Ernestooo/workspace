/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package iterator;

import characters.*;

public interface CharactersIterator {
	
	void init();
	
	boolean hasNext();
	
	Characters next();
	
	Rebel nextRebel();
	
	Stormtrooper nextStormtrooper();
	
	void searchNextRebel();
	
	void searchNextStormtrooper();
	
}
