/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package items;
import entities.EntitiesClass;

public class GunClass extends EntitiesClass implements Gun {
	
	public GunClass(){
		
	}

	@Override
	public char symbol() {
		// TODO Auto-generated method stub
		return Gun.GUN;
	}
	
	

}
