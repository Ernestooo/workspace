/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package items;

import entities.Entities;

public interface Potion extends Entities{
	
	static final char POTION = 'P';
}
