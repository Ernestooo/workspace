/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package characters;

public interface StormtrooperBlack  extends Stormtrooper{
	
	static final char STORMB = 'B';
	
	
}
