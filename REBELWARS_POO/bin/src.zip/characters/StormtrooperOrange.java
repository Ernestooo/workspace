/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package characters;

public interface StormtrooperOrange extends Stormtrooper {
	
	static final char STORMO = 'O';
	
}
