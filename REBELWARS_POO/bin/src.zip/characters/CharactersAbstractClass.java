/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package characters;

import entities.EntitiesClass;

public abstract class CharactersAbstractClass extends EntitiesClass implements Characters {
	
	private int countCaptured;
	private int row;
	private int col;
	private Characters[] captured;
	protected String state;
	private boolean capture;
	
	public CharactersAbstractClass(){
		countCaptured = 0;
		captured = new Characters[DEFAULT_SIZE];
		state = "Active";
		capture = false;
	}
	
	public void capture(Characters c){
		if(countCaptured == captured.length)
			resizeCaptured();
		captured[countCaptured++] = c;
	}
	
	private void resizeCaptured(){
		Characters[] tmp = new Characters[DEFAULT_SIZE*RESIZE];
		for(int i = 0; i < countCaptured; i++){
			tmp[i] = captured[i];
		}
		captured = tmp;
	}
	
	public abstract String getName();
	
	public void arrive(int row, int col){
		this.row = row;
		this.col = col;
	}
	
	public void gotCaptured(){
		capture = true;
	}
	
	public boolean getCapture(){
		return capture;
	}
	
	public abstract void changeState();
	
	public String getState(){
		return state;
	}
	
	public int getRow(){
		return row;
	}
	
	public int getCol(){
		return col;
	}

	public abstract char symbol();
	
}
