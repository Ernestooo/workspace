/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package characters;

public class StormtrooperWhiteClass extends StormtrooperAbstractClass implements StormtrooperWhite{
	
	

	public StormtrooperWhiteClass() {
		super();
		
		// TODO Auto-generated constructor stub
	}

	@Override
	public char symbol() {
		// TODO Auto-generated method stub
		return StormtrooperWhite.STORMW;
	}
	
	public void addMovement(){
		movements[0] = Movements.L;
		movements[1] = Movements.R;
		movements[2] = Movements.D;
		movements[3] = Movements.U;
	}

}
