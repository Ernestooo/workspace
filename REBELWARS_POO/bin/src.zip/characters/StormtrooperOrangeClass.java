/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package characters;

public class StormtrooperOrangeClass extends StormtrooperAbstractClass implements StormtrooperOrange {

	public StormtrooperOrangeClass() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public char symbol() {
		// TODO Auto-generated method stub
		return StormtrooperOrange.STORMO;
	}
	
	public void addMovement(){
		movements[0] = Movements.R;
		movements[1] = Movements.D;
		movements[2] = Movements.L;
		movements[3] = Movements.U;
	}

}
