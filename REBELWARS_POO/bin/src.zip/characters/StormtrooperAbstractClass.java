/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package characters;

import iterator.*;

/**
 * 
 * @author Tiago Matias
 * @author Ivan Domingues
 *
 */

public abstract class StormtrooperAbstractClass extends CharactersAbstractClass implements Stormtrooper {
	
	protected Movements[] movements;
	private int countMovements;
	private int counter;
	private Rebel[] captured;
	private String name;

	public StormtrooperAbstractClass() {
		super();
		captured = new Rebel[DEFAULT_SIZE_STORM];
		counter = 0;
		movements = new Movements[MOVEMENTSIZE];
		countMovements = 4;
		name = null;
	}
	
	public void arrive(int row, int col){
		super.arrive(row, col);
	}
	
	public void captureRebel(Rebel r){
		if(counter == captured.length){
			resizeCaptured();
		}
		captured[counter++] = r;
	}
	
	private void resizeCaptured(){
		Rebel[] tmp = new Rebel[DEFAULT_SIZE_STORM*RESIZE];
		for(int i = 0; i < counter; i++){
			tmp[i] = captured[i];
		}
		captured = tmp;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public String getName(){
		return name;
	}
	
	public void changeState(){
		state = "Captured";
	}
	
	public abstract char symbol();
	
	public abstract void addMovement();
	
	public int getCountMove(){
		return countMovements;
	}
	
	public int getCounter(){
		return counter;
	}
	
	public MovementsIterator movesIterator(){
		return new MovementsIteratorClass(countMovements, movements);
	}

}
