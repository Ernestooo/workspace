/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package characters;

public enum Movements {
	
	U, D, R, L;

}
