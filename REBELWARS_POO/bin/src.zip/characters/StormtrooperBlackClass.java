/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package characters;


public class StormtrooperBlackClass extends StormtrooperAbstractClass implements StormtrooperBlack {

	public StormtrooperBlackClass() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public char symbol() {
		// TODO Auto-generated method stub
		return StormtrooperBlack.STORMB;
	}
	
	public void addMovement(){
		movements[0] = Movements.U;
		movements[1] = Movements.D;
		movements[2] = Movements.L;
		movements[3] = Movements.R;
	}
	

}
