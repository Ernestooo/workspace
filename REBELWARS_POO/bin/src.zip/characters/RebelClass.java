/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package characters;

import iterator.PathIterator;
import iterator.PathIteratorClass;

public class RebelClass extends CharactersAbstractClass implements Rebel {
	
	private int countRows;
	private int countCols;
	private int[][] path;
	private int steps;
	private int points;
	private boolean superCharged;
	private String name;
	
	public RebelClass(String name){
		super();
		path = new int[DEFAULT_ROW_SIZE][DEFAULT_COL_SIZE];
		superCharged = false;
		steps = 0;
		this.name = name;
		countRows = 0;
		countCols = 0;
		points = 0;
	}
	
	public String getName(){
		return name;
	}
	
	public char symbol(){
		if(superCharged)
			return Rebel.SUPERCHARGED;
		return Rebel.REBEL;
	}
	
	public void arrive(int row, int col){
		super.arrive(row, col);
		path[countRows][X] = row;
		path[countRows++][Y] = col;
	}
	
	public int getCountRows(){
		return countRows;
	}
	
	public int getCountCols(){
		return countCols;
	}
	
	public void changeState(){
		if(getCapture())
			state = "Captured";
		else if(isSuperCharged())
			state = "SuperCharged";
	}
	
	public void move(){
		steps++;
	}
	
	public void drinkPotion(){
		superCharged = true;
		changeState();
	}
	
	public boolean isSuperCharged(){
		return superCharged;
	}
	
	public int getPoints(){
		return points;
	}
	
	public void captureGun(){
		points += 10;
	}
	
	public int getSteps(){
		return steps;
	}
	
	public PathIterator pathIterator(){
		return new PathIteratorClass(path, countRows, countCols);
	}

	
}
