/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package map;

import entities.Entities;

public interface EmptySpace {
	
	static final char EMPTY = ' ';
	
	/**
	 * 
	 * @param e exists
	 */
	void addEntity(Entities e);
	
	void removeEntity(Entities e);
	
	char interact();
	
	boolean hasRebel();
	
	boolean hasGun();
}
