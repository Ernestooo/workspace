/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package map;

import characters.*;
import entities.Entities;
import items.*;

public class EmptySpaceClass extends LocationAbstractClass implements EmptySpace {
	
	private static final int MAX_VALUE = 3;
	
	private Entities[] entities;
	private int counter;
	private Gun gun;
	private Potion potion;
	private Rebel rebel, superCharged;
	private StormtrooperBlack stormtrooperB;
	private StormtrooperWhite stormtrooperW;
	private StormtrooperOrange stormtrooperO;
	
	public EmptySpaceClass(){
		super();
		entities = new Entities[MAX_VALUE];
		counter = 0;
		gun = null;
		potion = null;
		stormtrooperB = null; 
		stormtrooperW = null;
		stormtrooperO = null;
		rebel = null;
		superCharged = null;
		//emptySpace = ;
	}

	@Override
	public char symbol() {
		char c = interact();
		return c;
	}
	
	public void addEntity(Entities e){
		entities[counter++] = e;
		if(e instanceof Gun){
			gun = (Gun) e;
		}
		else if(e instanceof Potion){
			potion = (Potion) e;
		}
		else if(e instanceof Rebel && ((Rebel) e).isSuperCharged()){
			superCharged = (Rebel) e;
		}
		else if(e instanceof Rebel){
			rebel = (Rebel) e;
		}
		else if(e instanceof StormtrooperBlack){
			stormtrooperB = (StormtrooperBlack) e;
		}
		else if(e instanceof StormtrooperWhite){
			stormtrooperW = (StormtrooperWhite) e;
		}
		else if(e instanceof StormtrooperOrangeClass){
			stormtrooperO = (StormtrooperOrange) e;
		}
	}
	
	public void removeEntity(Entities e){
		for(int i = 0; i < counter; i++){
			if(entities[i].equals(e)){
				for(int j = i+1; j < counter; j++){
					entities[j-1] = entities[j];
				}
			}
		}
		if(e instanceof Rebel){
			superCharged = null;
			rebel = null;
		}
		else if(e instanceof Stormtrooper){
			stormtrooperB = null;
			stormtrooperW = null;
			stormtrooperO = null;
		}
		else if(e instanceof Gun){
			gun = null;
		}
		else if(e instanceof Potion){
			potion = null;
		}
	}
	
	@SuppressWarnings("static-access")
	public char interact(){
		char c = ' ';
		if(rebel != null && stormtrooperB != null){
			c = stormtrooperB.symbol();
			((Stormtrooper)getEntity("Stormtrooper")).captureRebel((Rebel)getEntity("Rebel"));
			removeEntity((Rebel)getEntity("Rebel"));
			rebel = null;
		}
		else if(rebel != null && stormtrooperW != null){
			c = stormtrooperW.symbol();
			((Stormtrooper)getEntity("Stormtrooper")).captureRebel((Rebel)getEntity("Rebel"));
			removeEntity((Rebel)getEntity("Rebel"));
			rebel = null;
		}
		else if(rebel != null && stormtrooperO != null){
			c = stormtrooperO.symbol();
			((Stormtrooper)getEntity("Stormtrooper")).captureRebel((Rebel)getEntity("Rebel"));
			removeEntity((Rebel)getEntity("Rebel"));
			rebel = null;
		}
		else if(rebel != null && gun != null){
			c = rebel.symbol();
			removeEntity((Gun)getEntity("gun"));
			gun = null;
		}
		else if(rebel != null && potion != null){
			c = superCharged.SUPERCHARGED;
			((Rebel)getEntity("Rebel")).drinkPotion();
			removeEntity((Potion)getEntity("Potion"));
			potion = null;
		}
		else if(superCharged != null && stormtrooperB != null){
			c = superCharged.symbol();
			removeEntity((Stormtrooper)getEntity("Stormtrooper"));
			stormtrooperB = null ;
		}
		else if(superCharged != null && stormtrooperW != null){
			c = superCharged.symbol();
			removeEntity((Stormtrooper)getEntity("Stormtrooper"));
			stormtrooperW = null ;
		}
		else if(superCharged != null && stormtrooperO != null){
			c = superCharged.symbol();
			removeEntity((Stormtrooper)getEntity("Stormtrooper"));
			stormtrooperO = null ;
		}
		else if(stormtrooperB != null && gun != null){
			c = stormtrooperB.symbol();
		}
		else if(stormtrooperB != null){
			c = stormtrooperB.symbol();
		}
		else if(gun != null){ 
			c = gun.GUN;
		}
		else if(potion != null){
			c = potion.POTION;
		}
		else if(rebel != null){
			c = rebel.symbol();
		}
		else if(superCharged != null){
			c = superCharged.symbol();
		}
		else{
			gun = null;
			potion = null;
			stormtrooperB = null; 
			stormtrooperW = null;
			stormtrooperO = null;
			rebel = null;
			superCharged = null;
		}
		return c;
	}
	
	private Entities getEntity(String type){
		Entities e = null;
		for(int i = 0; i < counter; i++){
			if(type.equalsIgnoreCase("Stormtrooper")){
				if(entities[i] instanceof Stormtrooper){
					e = entities[i];
				}
			}
			else if(type.equalsIgnoreCase("Rebel")){
				if(entities[i] instanceof Rebel){
					e = entities[i];
				}
			}
			else if(type.equalsIgnoreCase("gun")){
				if(entities[i] instanceof Gun){
					e = entities[i];
				}
			}
			else if(type.equalsIgnoreCase("potion")){
				if(entities[i] instanceof Potion){
					e = entities[i];
				}
			}
		}
		return e;
	}

	@Override
	public boolean hasRebel() {
		boolean control = false;
		for(int i = 0; i < counter; i++){
			if(entities[i] instanceof Rebel)
				control = true;
		}
		return control;
	}
	
	public boolean hasGun(){
		return gun != null;
	}

}
