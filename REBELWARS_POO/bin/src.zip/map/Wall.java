/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package map;

public interface Wall {
	
	static final char WALL = '#';

}
