/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package map;

import characters.*;

public interface Map {
	int getRows();
	
	int getColumns();
	
	Location getLocation(int row, int col);
	
	void addRebel(Rebel rebel, int r, int col);
	
	void removeRebel(Rebel rebel, int r, int c);
	
	void addStormtrooper(Stormtrooper s, int r, int c);
	
	void removeStormtrooper(Stormtrooper s, int r, int c);
	
	boolean isEmpty(int r, int c);
	
	boolean isValidPosition(int r, int c);
	
	boolean isInsideMap(int r, int c);
	
	boolean canMove(int r, int c);
}
