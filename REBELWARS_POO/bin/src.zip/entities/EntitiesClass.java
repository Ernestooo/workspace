/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package entities;

public abstract class EntitiesClass implements Entities {
	
	public EntitiesClass(){
		
	}

	public abstract char symbol();

}
