/**
 * @author Ivan Domingues - 49948 || Tiago Matias - 50751
 *
 */

package rebelwars;

import characters.*;
import iterator.*;
import map.*;


public class RebelWarsClass implements RebelWars {
	
	private static final int DEFAULT_SIZE = 100;
	private static final int RESIZE		  = 2;
	
	private Characters[] characters;
	private int countRebels;
	//private int countStormtroopers;
	private Map map;
	private int countCharacters;
	private int points;
	private int timer;
	private String status;
	
	public RebelWarsClass(){
		characters = new Characters[DEFAULT_SIZE];
		countRebels = 0;
		map = null;
		countCharacters = 0;
	//	countStormtroopers = 0;
		points = 0;
		timer = 0;
		status = "Setup";
	}
	
	public void addRebel(String name, int row, int col){
		Rebel r = new RebelClass(name);
		if(countCharacters == characters.length)
			resize();
		r.arrive(row, col);
		map.addRebel(r, row, col);
		characters[countCharacters++] = r;
		countRebels++;
	}
	/**

	public void addStormtrooper(int row, int col){
		Stormtrooper s = null;
		if(map.getLocation(row, col).symbol() == StormtrooperBlack.STORMB){
			s = new StormtrooperBlackClass();
			((EmptySpace)map.getLocation(row, col)).addEntity(s);
			s.setName("ST-B-" + countStormtroopers);
		}
		else if(map.getLocation(row, col).symbol() == StormtrooperWhite.STORMW){
			s = new StormtrooperWhiteClass();
			((EmptySpace)map.getLocation(row, col)).addEntity(s);
			s.setName("ST-W-" + countStormtroopers);
		}
		else if(map.getLocation(row, col).symbol() == StormtrooperOrange.STORMO){
			s = new StormtrooperOrangeClass();
			((EmptySpace)map.getLocation(row, col)).addEntity(s);
			s.setName("ST-O-" + countStormtroopers);
		}
		if(countCharacters == characters.length)
			resize();
		s.arrive(row,col);
		map.addStormtrooper(s, row, col);
		characters[countCharacters++] = s;
		countStormtroopers++;
	}
		
	 */
	private void resize(){
		Characters[] tmp = new Characters[DEFAULT_SIZE*RESIZE];
		for(int i = 0; i < countCharacters; i++){
			tmp[i] = characters[i];
		}
		characters = tmp;
	}
	
	public boolean isWall(int row, int col){
		return map.getLocation(row, col) instanceof Wall;
	}
	
	public Rebel getRebel(String name){
		return (Rebel) characters[searchIndex(name)];
	}
	
	public int getMapRows(){
		return map.getRows();
	}
	
	public int getMapCols(){
		return map.getColumns();
	}
	
	public void removeRebelCell(String name){
		map.removeRebel(((Rebel)characters[searchIndex(name)]), ((Rebel)characters[searchIndex(name)]).getRow(), ((Rebel)characters[searchIndex(name)]).getCol());
	}
	
	public void addRebelCell(String name){
		map.addRebel(((Rebel)characters[searchIndex(name)]), ((Rebel)characters[searchIndex(name)]).getRow(), ((Rebel)characters[searchIndex(name)]).getCol());
	}
	
	
	public boolean isEmpty(int r, int c){
		return map.isEmpty(r, c);
	}
	
	public int searchIndex(String name){
		int index = -1;
		for(int i = 0; i < countCharacters; i++){
			if(characters[i].getName().equals(name))
				index = i;
		}
		return index;
	}
	
	public boolean hasRebel(String name){
		return searchIndex(name) >= 0;
	}
	
	public boolean hasStormtrooper(String id){
		return searchIndex(id) >= 0;
	}
	
	public boolean hasRebels(){
		return countRebels > 0;
	}
	
	public boolean hasCharacters(){
		return countCharacters > 0;
	}
	
	public void uploadMap(int row, int col, char[][] map){
		this.map = new MapClass(map, row, col);
	}
	
	public boolean hasMap(){
		return map != null;
	}
	
	public int getPoints(){
		return points;
	}
	
	public void incPoints(){
		points += 10;
	}
	
	public int getTimer(){
		return timer;
	}
	
	public void incTimer(){
		timer++;
	}
	
	public String getStatus(){
		return status;
	}
	
	public int getCountRebels(){
		return countRebels;
	}
	
	public MapIterator mapIterator(){
		return new MapIteratorClass(map);
	}
	
	public CharactersIterator characterIterator(){
		return new CharactersIteratorClass(countCharacters, characters);
	}

	@Override
	public void start() {
		status = "ON";
	}

	@Override
	public void reset() {
		characters = new Characters[DEFAULT_SIZE];
		countRebels = 0;
		map = null;
		countCharacters = 0;
		points = 0;
		timer = 0;
		status = "Setup";
	}

	@Override
	public boolean isValidLocation(int r, int c) {
		// TODO Auto-generated method stub
		return map.isValidPosition(r, c);
	}
	
	public void moveRebel(Rebel r, Movements move){
		int actualR = r.getRow();
		int actualC = r.getCol();
		EmptySpace es = (EmptySpace) map.getLocation(actualR, actualC);
		if(move.equals(Movements.U)){
			if(map.isInsideMap(actualR-1, actualC) && map.canMove(actualR-1, actualC)){
				es.removeEntity(r);
				map.addRebel(r, actualR-1, actualC);
				if(((EmptySpace)map.getLocation(actualR-1, actualC)).hasGun())
					incPoints();
				r.arrive(actualR-1, actualC);
				r.move();
			}
		}
		else if(move.equals(Movements.D)){
			if(map.isInsideMap(actualR+1, actualC) && map.canMove(actualR+1, actualC)){
				es.removeEntity(r);
				map.addRebel(r, actualR+1, actualC);
				if(((EmptySpace)map.getLocation(actualR+1, actualC)).hasGun())
					incPoints();
				r.arrive(actualR+1, actualC);
				r.move();
			}
		}
		
		else if(move.equals(Movements.R)){
			if(map.isInsideMap(actualR, actualC+1) && map.canMove(actualR, actualC+1)){
				es.removeEntity(r);
				map.addRebel(r, actualR, actualC+1);
				if(((EmptySpace)map.getLocation(actualR, actualC+1)).hasGun())
					incPoints();
				r.arrive(actualR, actualC+1);
				r.move();
			}
		}
		else if(move.equals(Movements.L)){
			if(map.isInsideMap(actualR, actualC-1) && map.canMove(actualR, actualC-1)){
				es.removeEntity(r);
				map.addRebel(r, actualR, actualC-1);
				if(((EmptySpace)map.getLocation(actualR, actualC-1)).hasGun())
					incPoints();
				r.arrive(actualR, actualC-1);
				r.move();
			}
		}
	}

}
